# Load sample file 
import pandas as pd 


df = pd.read_csv('sample.csv', sep='|', index_col="POLICY")

print(df[(df['ETL_TRANSACTION_DS'].str.upper() == 'ENDORSEMENT') and (df['ETL_TRANSACTION_DS'] == 3)])

exit(0)

df['COVEND'] = 0
df['EDSNO'] = df['ETL_TRANSACTION_NB'] -1



print(df.loc[:,df.columns.isin(['POLICY','COVEND','ETL_TRANSACTION_DS','ETL_TRANSACTION_NB','ETL_cov_COVERAGE_CD','EDSNO'])])